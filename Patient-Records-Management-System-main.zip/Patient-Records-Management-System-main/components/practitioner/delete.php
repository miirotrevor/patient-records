<?php include("header.php") ?>
<div class="container">
    <?php require("process-delete-record.php") ?>
</div>
<?php include("footer.php") ?>