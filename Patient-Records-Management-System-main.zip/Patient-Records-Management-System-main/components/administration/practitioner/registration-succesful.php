<?php
require("../session.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../app/app.css">
    <title>Success</title>
</head>

<body>
    <div class="container" style="text-align: center;">
        <div class="row registrationmode">
            <div class="col-25">
                <div class="circle success">

                </div>
            </div>
            <div class="col-75">
                <h3>Registration successful</h3>
            </div>
        </div>
        <p>View records <a href="administrator-viewrecordspractioner.php">Here</a></p>
    </div>
</body>

</html>