<?php include("header.php") ?>
<div class="container">
    <div class="row">
        <div class="col-md-4 m-auto">
            <h5>Are you sure you want to log out</h5>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eligendi, voluptatem quidem? Nisi magnam debitis quas voluptate maxime tempore eius quo consectetur perferendis. Quidem eum quod magni, quas iure quam autem?</p>
            <div class="row">
                <div class="col-md-6">
                    <a class="btn btn-warning btn-sm w-100" href="process-logout.php">Yes</a>
                </div>
                <div class="col-md-6">
                    <a class="btn btn-color btn-sm w-100" href="">No</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include("footer.php") ?>