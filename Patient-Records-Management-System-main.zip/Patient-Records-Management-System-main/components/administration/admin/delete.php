<?php include("header.php") ?>
<?php require("process-delete-record.php") ?>
<?php include("footer.php") ?>