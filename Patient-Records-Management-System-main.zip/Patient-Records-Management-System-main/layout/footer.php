</main>

<footer class="bg-light text-center text-lg-start">
    <!-- Copyright -->
    <div class="footer text-center p-3"">
© 2022 Copyright: HIT Clinic Project
</div>
<!-- Copyright -->
</footer>
</body>
</html>