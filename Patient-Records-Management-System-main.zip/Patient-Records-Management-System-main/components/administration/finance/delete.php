<?php include("header.php") ?>
<?php require("process-delete-record.php") ?>
</div>
<?php include("footer.php") ?>